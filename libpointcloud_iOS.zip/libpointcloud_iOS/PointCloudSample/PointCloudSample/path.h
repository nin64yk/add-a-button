void dumpPath();
char* getDocumentPath();
char* createFileName(const char* filename);